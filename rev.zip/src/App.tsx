import './App.css'
import './fonts/fonts.css'
import AuthModal from "./Components/Modals/AuthModal/AuthModal.tsx";
import {isAuthenticated} from "./api/auth.ts";
import {useEffect, useState} from "react";
import Loading from "./Components/Modals/Loading/Loading.tsx";
import Sidebar from "./Components/Layout/Sidebar/Sidebar.tsx";
import MainContent from "./Components/Layout/MainContent/MainContent.tsx";
import {Snowfall} from "react-snowfall";
import {createPortal} from "react-dom";

function App() {
    const [auth, setAuth] = useState<boolean | null>(null);

    useEffect(() => {
        const checkAuth = async () => {
            const isAuth: boolean = await isAuthenticated()
            setAuth(isAuth)
        }

        checkAuth()
    }, [])

    console.log(auth)
    return (
    <div className="mainCont">
        {createPortal(<Snowfall
            style={{zIndex: -1, position: "fixed"}}
            snowflakeCount={130}
            speed={[1, 1.5]}
            wind={[0.1, 0.1]}
            radius={[0.5, 3]}
            />,
            document.body
        )}

        {auth === null && createPortal(<Loading/>, document.body)}
        {auth === true && 
            <>
                <Sidebar setAuth={setAuth}/>
                <MainContent/>
            </>
        }
        {auth === false && <AuthModal setAuth={setAuth} />}
    </div>
  )
}

export default App
