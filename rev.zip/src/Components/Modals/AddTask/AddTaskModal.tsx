import './AddTask.css';
import type {Priority, TaskStatus} from "../../../types";
import {type ChangeEvent, type FormEvent, useState} from "react";
import {DatePickerInput} from "@mantine/dates";


interface AddTaskModalProps {
    open: boolean;
    onClose: () => void;
    onCreateTask: (title: string, priority: Priority, status: TaskStatus, time: Date) => void;
    handleError: (message: string) => void;
    handleSuccess: (message: string) => void;
}

const AddTaskModal = ({open, onClose, onCreateTask, handleError, handleSuccess}: AddTaskModalProps) => {
    const [nameTask, setNameTask] = useState<string>('');
    const [priorityTask, setPriorityTask] = useState<Priority>('low');
    const [statusTask, setStatusTask] = useState<TaskStatus>('todo');

    const [date, setDate] = useState<Date>();

    if (!open) return null;

    function createTask() {
        if (!date) {
            handleError('Выберите дату')
            return;
        }
        if (nameTask.length < 3) {
            handleError('Недопустимая длина задачи');
            return;
        }
        onCreateTask(nameTask, priorityTask, statusTask, date);
        handleSuccess('Задача успешно добавлена!');

        onClose();
    }

    const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        createTask()
    };

    const handleButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        createTask()
    };


    return (
        <div className="modal" onClick={onClose}>
            <div
                className="modal-card modal-task"
                onClick={e => e.stopPropagation()}
            >

                <button
                    className="modal-close"
                    aria-label="close"
                    onClick={onClose}
                >
                    ✕
                </button>

                <div className="modal-title">
                    ➕ Новая задача
                </div>

                <label htmlFor="titleInput" className='addTaskLabel'>Введите название</label>
                <form action="" onSubmit={(event: FormEvent<HTMLFormElement>) => handleSubmit(event)}>
                    <input
                        id="titleInput"
                        value={nameTask}
                        onChange={(event: ChangeEvent<HTMLInputElement>) =>
                            setNameTask(event.target.value)
                        }
                        placeholder="Название"
                    />
                </form>

                <label htmlFor="priorityInput" className='addTaskLabel'>Выберите приоритет</label>
                <select id="priorityInput" onChange={(event: ChangeEvent<HTMLSelectElement>) => setPriorityTask(event.target.value as Priority)}>
                    <option value="high">Высокий приоритет</option>
                    <option value="medium">Средний приоритет</option>
                    <option value="low">Низкий приоритет</option>
                </select>

                <label htmlFor="columnInput" className='addTaskLabel'>Выберите статус</label>
                <select id="columnInput" onChange={(event: ChangeEvent<HTMLSelectElement>) => setStatusTask(event.target.value as TaskStatus)}>
                    <option value="todo">К выполнению</option>
                    <option value="progress">В процессе</option>
                    <option value="done">Завершено</option>
                </select>

                <DatePickerInput
                    label="Дата"
                    placeholder="Выберите дату"
                    value={date}
                    onChange={setDate as unknown as (value: string | null) => void}
                    classNames={{
                        label: 'my-date-label',
                        input: 'my-date-input',
                        calendarHeader: 'my-date-header',
                        day: 'my-date-day',
                    }}
                    popoverProps={{
                        withinPortal: false,
                        classNames: {
                            dropdown: 'my-date-dropdown'
                        }
                    }}
                />

                <button
                    id="createTask"
                    className="primary"
                    onClick={handleButtonClick}
                >
                    Создать задачу
                </button>

            </div>
        </div>
    );
};

export default AddTaskModal;