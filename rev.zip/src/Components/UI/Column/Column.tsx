import './Column.css';
import type {Task} from "../../../types";

interface ColumnProps {
    status: string;
    title: string;
    tasks: Array<Task>
}
const Column = ({title, tasks, status}: ColumnProps) => {
    const priorityWeight = {
        high: 1,
        medium: 2,
        low: 3,
    }

    const filteredTasks = tasks.filter(task => task.status === status)
    return (
        <div className="column">
            <div className="columnHeader">
                <div className="columnTitle">{title}</div>
                <div className="counter">{filteredTasks.length}</div>
            </div>

            <div className="tasks">
                {filteredTasks.sort((a, b) => priorityWeight[a.priority] - priorityWeight[b.priority]).map((task) => {
                    return <div key={task.id} className="task">
                        <div className="taskTitle">{task.title}</div>
                        <div className="meta">
                            <span>{task.time}</span>
                            <span className={task.priority}>{task.priority}</span>
                        </div>
                    </div>
                })}
            </div>

            <button className="addTask">
                + Добавить задачу
            </button>
        </div>
    );
};

export default Column;