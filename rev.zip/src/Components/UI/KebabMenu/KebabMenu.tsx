import './KebabMenu.css';
import {useEffect, useRef, useState} from "react";

const KebabMenu = () => {
    const [openMainMenu, setOpenMainMenu] = useState(false);
    const [openSecondMenu, setOpenSecondMenu] = useState(false);

    const element = useRef<HTMLDivElement | null>(null)

    useEffect(() => {
        if (!openMainMenu) return

        const onclick = function (event: MouseEvent) {
            const el = element.current;

            if (!el?.contains(event.target as Node)) {
                setOpenMainMenu(false)
                setOpenSecondMenu(false)
            }
        }

        const onkeydown = function (event: KeyboardEvent) {
            if (event.key === 'Escape') {
                setOpenMainMenu(false)
                setOpenSecondMenu(false)
            }
        }

        document.addEventListener('click', onclick)
        document.addEventListener('keydown', onkeydown)

        return () => {
            document.removeEventListener('click', onclick)
            document.removeEventListener('keydown', onkeydown)
        }
    }, [openMainMenu]);

    return (
        <div className="kebab-wrapper" ref={element}>
            <button
                className="kebab-btn"
                onClick={() => setOpenMainMenu(prev => !prev)}
            >
                <span className="kebab-dot" />
                <span className="kebab-dot" />
                <span className="kebab-dot" />
            </button>

            {openMainMenu && (
                <div className="dropdown-menu">
                    <button className="danger">Очистить</button>
                    <button onClick={() => setOpenSecondMenu(prev => !prev)}>Переместить в... →</button>

                    {openSecondMenu && (
                        <ul className='double-dropdown'>
                            <button>К выполнению</button>
                            <button>В процессе</button>
                            <button>Завершено</button>
                            <button>Архив</button>
                        </ul>
                    )}
                </div>
            )}
        </div>
    );
};

export default KebabMenu;